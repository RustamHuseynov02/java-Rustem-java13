package com.example.springjavatest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJavaTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
