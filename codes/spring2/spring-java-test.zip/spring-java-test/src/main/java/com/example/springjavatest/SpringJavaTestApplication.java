package com.example.springjavatest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJavaTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJavaTestApplication.class, args);
	}

}
